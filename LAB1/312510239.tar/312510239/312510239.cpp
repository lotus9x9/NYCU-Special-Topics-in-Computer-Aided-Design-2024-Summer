#include<bits/stdc++.h>
using namespace std;

string binary_to_literal(const string &binary) {
    string literal;
    for (int i = 0; i < binary.size(); i++) {
        if (binary[i] == '1') {
            literal += char('A' + i); 
        } else if (binary[i] == '0') {
            literal += char('A' + i);
            literal += "'";
        }
    }
    return literal;
}

int literalcount(const string &implicant) {
    return count_if(implicant.begin(), implicant.end(), [](char c) { return c == '1' || c == '0'; });
}

bool literal_compare(const string &a, const string &b) {
    int a_literals = literalcount(a);
    int b_literals = literalcount(b);

    if (a_literals != b_literals) {
        return a_literals > b_literals; 
    }
    return a > b;
}

class Quine_McCluskey
{
private:
    int var_num;
    vector<string>on_set;
    unordered_set<string>dont_care;
    set<string>all_set;
    vector<string> prime_implicants;
    int min_imp;
    vector<vector<string>> notess;
    vector<set<string>> patrick_imp;
    vector<string> best_sol;
public:
    Quine_McCluskey() : min_imp(INT_MAX) {}
    ~Quine_McCluskey() {}
    //Input File
    void inputfile(string filename){
        ifstream input(filename);
        string tmp;
        int decimal;
        string binary;
        input>>tmp>>var_num;
        input>>tmp;
        while (!input.eof())
        { 
            input>>tmp;
            if (tmp==".d") break;
            decimal=stoi(tmp);
            binary=Decimal_To_Binary(decimal);
            on_set.push_back(binary);
            all_set.insert(binary);
        }
        while (!input.eof())
        {
            input>>decimal;
            binary=Decimal_To_Binary(decimal);
            dont_care.insert(binary);
            all_set.insert(binary);
        }
        input.close();
    }
    //Change decimal to binary
    string Decimal_To_Binary(int decimal) {
        if (decimal == 0) return string(var_num, '0'); 
        string binary = "";
        while (decimal > 0) {
            binary = (decimal % 2 == 0 ? "0" : "1") + binary;
            decimal /= 2;
        }
        while (binary.size() < var_num) {
            binary = "0" + binary;
        }
        return binary;
    }
    //Find prime implicants
    void find_prime_implicants() {
        while (!all_set.empty()) {
            vector<bool> check_list(all_set.size(), false);
            set<string> n_prime;
            string tmp;
            int counta = 0;
            for (auto it1 = all_set.begin(); it1 != all_set.end(); it1++, counta++) {
                int countb = counta + 1;
                for (auto it2 = next(it1); it2 != all_set.end(); it2++, countb++) {
                    int diff=0;
                    tmp=*it1;
                    for( int i=0; i<(*it1).length(); i++ ) {
                        if( (*it1)[i]!=(*it2)[i]){
                            diff++;
                            tmp[i]='-';
                        }
                    }
                    if (diff==1) {
                        check_list[counta] = true;
                        check_list[countb] = true;
                        n_prime.insert(tmp);
                    }
                }
            }
            for (int i = 0; i < check_list.size(); i++) {
                if (!check_list[i]) {
                    prime_implicants.push_back(*next(all_set.begin(), i));
                }
            }
            all_set.clear();
            all_set.insert(n_prime.begin(), n_prime.end());
        }
        return;
    }   
    //檢查兩組string是否能覆蓋
    bool checkPrime(const string& a,const string& b){
        for (int i = 0; i < var_num; i++) {
            if (a[i] != '-' && a[i] != b[i]) {
                return false;
            }
        }
        return true;
    }
    //使用patrick算法來找到minimum cover
    void patrick_algorithm(set<string>& patrick_set, int idx, int iter) {
        if (iter > min_imp) return;
        if (idx == notess.size()) {
            if (iter <= min_imp) {
                min_imp = iter;
                patrick_imp.push_back(patrick_set); 
            }
            return;
        }
        const auto& implicants = notess[idx];
        for (const auto& implicant : implicants) {
            if (patrick_set.insert(implicant).second) {
                patrick_algorithm(patrick_set, idx + 1, iter + 1);
                patrick_set.erase(implicant);
            } else {
                patrick_algorithm(patrick_set, idx + 1, iter);
            }
        }
        return;
    }

    void generate_prime_implicant_chart(vector<vector<int>>& prime_Imp_chart) {
        prime_Imp_chart.assign(prime_implicants.size() + 1, vector<int>(on_set.size() + 1, 0));
        for (int i = 0; i < prime_implicants.size(); i++) {
            for (int j = 0; j < on_set.size(); j++) {
                if (checkPrime(prime_implicants[i], on_set[j])) {
                    prime_Imp_chart[i][j] = 1;
                    prime_Imp_chart[prime_implicants.size()][j]++;
                    prime_Imp_chart[i][on_set.size()]++;
                }
            }
        }
    }

    void select_essential_solutions(vector<vector<int>>& prime_Imp_chart) {
        for (int i = 0; i < on_set.size(); i++) {
            if (prime_Imp_chart[prime_implicants.size()][i] == 1) {
                prime_Imp_chart[prime_implicants.size()][i] = 0;
                for (int j = 0; j < prime_implicants.size(); j++) {
                    if (prime_Imp_chart[j][i] == 1) {
                        best_sol.push_back(prime_implicants[j]);
                        prime_Imp_chart[j][on_set.size()] = 0;
                        for (int k = 0; k < on_set.size(); k++) {
                            if (prime_Imp_chart[j][k] == 1) {
                                prime_Imp_chart[prime_implicants.size()][k] = 0;
                            }
                        }
                        break;
                    }
                }
            }
        }
    }

    void find_uncovered_implicants(vector<vector<int>>& prime_Imp_chart) {
        for (int i = 0; i < on_set.size(); i++) {
            if (prime_Imp_chart[prime_implicants.size()][i] != 0) {
                vector<string> primes;
                for (int j = 0; j < prime_implicants.size(); j++) {
                    if (prime_Imp_chart[j][i] != 0) {
                        primes.push_back(prime_implicants[j]);
                    }
                }
                notess.push_back(primes);
            }
        }
    }

    void minimum_cover() {
        vector<vector<int>> prime_Imp_chart;
        generate_prime_implicant_chart(prime_Imp_chart);
        select_essential_solutions(prime_Imp_chart);
        find_uncovered_implicants(prime_Imp_chart);
        set<string> min_cov;
        patrick_algorithm(min_cov,0,0);
        set<string> best_solutions;
        int min_literal = INT_MAX;
        for (const auto& solution : patrick_imp) {
            if (solution.size() == min_imp) {
                int count = 0;
                for (const auto& iter : solution) {
                    count += literalcount(iter);
                }
                if (count <= min_literal) {
                    min_literal = count;
                    best_solutions=solution;
                }
            }
        }
        for (const auto& iter : best_solutions) {
            best_sol.push_back(iter);
        }
        return;
    }
    
    void outputfile(string filename) {
        ofstream output(filename);
        stringstream streambuf;
        string s;
        streambuf << prime_implicants.size();
        output << ".p " << streambuf.str() << endl;
        sort(prime_implicants.begin(), prime_implicants.end(), [](const string &a, const string &b) {
            return literal_compare(a,b);
        });
        int size = prime_implicants.size();
        for (int i = 0; i < min(size, 15); i++) {
            s = binary_to_literal(prime_implicants[i]);
            output << s << endl;
        }
        output << endl;
        streambuf.str("");
        streambuf.clear();
        streambuf << best_sol.size();
        output << ".mc " << streambuf.str() << endl;
        sort(best_sol.begin(), best_sol.end(), [](const string &a, const string &b) {
            return literal_compare(a,b);
        });
        size = best_sol.size();
        int literals = 0;
        for (int i = 0; i < size; i++) {
            s = binary_to_literal(best_sol[i]);
            literals += literalcount(best_sol[i]);
            output << s << endl;
        }
        output << "literal=" << literals << endl;
        output.close();
    }
};

int main(int argc,char**argv){
    Quine_McCluskey Q;
    Q.inputfile(argv[1]);
    Q.find_prime_implicants();
    Q.minimum_cover();
    Q.outputfile(argv[2]);
    return 0;
}